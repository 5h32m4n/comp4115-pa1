select customerName from customers join (orders, orderdetails, products) on (orders.customerNumber=customers.customerNumber and orderdetails.orderNumber=orders.orderNumber and products.productCode=orderdetails.productCode) where productName="The Titanic";

select reps.firstName,reps.lastName from employees bosses, employees reps where bosses.employeeNumber=reps.reportsTo and bosses.lastName="Bow";

select contactFirstName,contactLastName from customers join (payments) on (payments.customerNumber=customers.customerNumber) where amount < 10000.00;

select contactFirstName,contactLastName,country,creditLimit from customers where country!="USA" and creditLimit > 100000;

select firstName,lastName from employees join (customers, orders) on (customers.salesRepEmployeeNumber=employees.employeeNumber and orders.customerNumber=customers.customerNumber) where status="cancelled";

select customerName,state,creditLimit from customers where country="USA" group by creditLimit DESC;

select customerName,phone from customers join (orders) on (orders.customerNumber=customers.customerNumber) where shippedDate > requiredDate;

select productName,quantityOrdered from products join (orderdetails) on (orderdetails.productCode=products.productCode) group by quantityOrdered DESC;